"""
Safe Web Scanner (Educational, Nessus/Nmap-inspired)

Features:
- Dashboard with charts and scan history
- New Scan page with plugin selection + "Select All"
- Reports list + detailed report per scan
- Download report as HTML or PDF
- Light/Dark theme toggle
- About / Methodology page
- Plugins page: view built-in plugins + create simple custom plugins from the UI

Built-in plugins (safe, low-impact):
- Basic Site Check
- Security Headers
- HTTPS / TLS & HSTS
- Basic TCP Port Visibility (Nmap-inspired)
- Cookie Security Flags
- robots.txt
- Tech Fingerprint (info)
- Basic Performance (info)
- Raw Response Headers (info)

Custom plugins (created in browser):
- Simple "keyword in HTML" checks you define on /plugins

Use only on systems you own or have permission to test.
"""

from flask import (
    Flask,
    request,
    render_template,
    redirect,
    url_for,
    make_response,
)
import requests
import socket
from urllib.parse import urlparse
from datetime import datetime
from io import BytesIO
import uuid
import time

from xhtml2pdf import pisa  # pip install xhtml2pdf

app = Flask(__name__)

# In-memory storage for scan results: scan_id -> scan_data
SCAN_RESULTS = {}

# In-memory storage for UI-created custom plugins
# Each item: {
#   "id": "custom_<uuid>",
#   "name": str,
#   "short": str,
#   "description": str,
#   "keyword": str,
#   "category": "Custom",
#   "default_enabled": bool
# }
CUSTOM_PLUGINS = []


# ----------------- Helper functions ----------------- #

def normalize_url(target):
    """Make sure the URL has http/https. Default to https://."""
    target = target.strip()
    if not target.startswith(("http://", "https://")):
        target = "https://" + target
    return target


def html_to_pdf(html_content):
    """Convert HTML string to PDF bytes using xhtml2pdf."""
    pdf_buffer = BytesIO()
    pisa_status = pisa.CreatePDF(html_content, dest=pdf_buffer)
    if pisa_status.err:
        return None
    pdf_buffer.seek(0)
    return pdf_buffer.getvalue()


def compute_overall_status(plugin_results):
    """Aggregate plugin statuses into one."""
    statuses = [p.get("status") for p in plugin_results]
    if any(s == "error" for s in statuses):
        return "error"
    if any(s == "warn" for s in statuses):
        return "warn"
    return "ok"


# -------- Custom plugin runner (UI-created keyword plugins) -------- #

def run_custom_keyword_plugin(plugin_id, target):
    """
    Run a custom keyword-based plugin created from the /plugins page.
    It:
    - fetches the page
    - searches HTML for keyword (case-insensitive)
    - OK if found, Needs Attention if not
    """
    config = next((p for p in CUSTOM_PLUGINS if p["id"] == plugin_id), None)
    if not config:
        return {
            "name": "Unknown custom plugin",
            "status": "error",
            "summary": "Custom plugin configuration not found.",
            "details": f"Plugin ID: {plugin_id}",
        }

    name = config["name"]
    keyword = config["keyword"]
    result = {"name": name, "status": "warn", "summary": "", "details": ""}

    try:
        resp = requests.get(target, timeout=10)
        html = resp.text.lower()
        key_lower = keyword.lower()

        lines = [
            f"Custom plugin: {name}",
            f"Keyword searched (case-insensitive): {keyword}",
            f"Target: {target}",
            "",
        ]

        if key_lower in html:
            result["status"] = "ok"
            result["summary"] = f"Keyword '{keyword}' was found in the HTML content."
            lines.append(f"Result: FOUND keyword '{keyword}' in response body.")
        else:
            result["status"] = "warn"
            result["summary"] = f"Keyword '{keyword}' was not found in the HTML content."
            lines.append(f"Result: DID NOT FIND keyword '{keyword}' in response body.")

        lines.append("")
        lines.append("Note: This is a simple keyword search plugin created from the UI.")
        result["details"] = "\n".join(lines)
    except Exception as e:
        result["status"] = "error"
        result["summary"] = "Custom keyword plugin failed while fetching the page."
        result["details"] = f"Error: {e}"

    return result


# ----------------- Built-in Plugins ----------------- #

def plugin_basic_info(target):
    """Basic Site Check: reachability, IP, status, server."""
    name = "Basic Site Check"
    result = {"name": name, "status": "warn", "summary": "", "details": ""}

    try:
        parsed = urlparse(target)
        host = parsed.hostname
        ip_addr = socket.gethostbyname(host) if host else "N/A"

        resp = requests.get(target, timeout=8, allow_redirects=True)
        status_code = resp.status_code
        final_url = resp.url
        server = resp.headers.get("Server", "Unknown")

        lines = [
            f"Target URL: {target}",
            f"Hostname: {host}",
            f"Resolved IP: {ip_addr}",
            f"Final URL after redirects: {final_url}",
            f"HTTP status code: {status_code}",
            f"Server header: {server}",
        ]

        if 200 <= status_code < 400:
            result["status"] = "ok"
            result["summary"] = f"Site is reachable and responded successfully (HTTP {status_code})."
        else:
            result["status"] = "warn"
            result["summary"] = f"Site responded but with non-2xx status (HTTP {status_code})."

        result["details"] = "\n".join(lines)
    except Exception as e:
        result["status"] = "error"
        result["summary"] = "Could not contact the site."
        result["details"] = f"Error while connecting or resolving: {e}"
    return result


def plugin_security_headers(target):
    """Check for common security headers (OWASP-style)."""
    name = "Security Headers"
    result = {"name": name, "status": "warn", "summary": "", "details": ""}

    important_headers = [
        "Content-Security-Policy",
        "Strict-Transport-Security",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy",
        "Permissions-Policy",
    ]

    try:
        resp = requests.get(target, timeout=8)
        headers = resp.headers

        lines = []
        missing = []

        for h in important_headers:
            if h in headers:
                lines.append(f"[OK] {h}: {headers[h]}")
            else:
                missing.append(h)
                lines.append(f"[MISSING] {h}")

        if not missing:
            result["status"] = "ok"
            result["summary"] = "Most important HTTP security headers are present."
        elif len(missing) < len(important_headers) / 2.0:
            result["status"] = "warn"
            result["summary"] = "Some security headers are missing: " + ", ".join(missing)
        else:
            result["status"] = "warn"
            result["summary"] = "Many key security headers are missing: " + ", ".join(missing)

        result["details"] = "\n".join(lines)
    except Exception as e:
        result["status"] = "error"
        result["summary"] = "Could not check security headers."
        result["details"] = f"Error: {e}"
    return result


def plugin_tls_https(target):
    """Check HTTPS usage and HSTS presence."""
    name = "HTTPS / TLS & HSTS"
    result = {"name": name, "status": "warn", "summary": "", "details": ""}

    try:
        parsed = urlparse(target)
        is_https = parsed.scheme == "https"
        lines = [f"URL scheme detected: {parsed.scheme}"]

        if not is_https:
            result["status"] = "warn"
            result["summary"] = "Site is using plain HTTP. HTTPS should be enabled."
            lines.append("Recommendation: Serve this site over HTTPS (TLS) with a valid certificate.")
        else:
            resp = requests.get(target, timeout=8)
            lines.append("HTTPS connection established successfully.")
            hsts = resp.headers.get("Strict-Transport-Security")

            if hsts:
                lines.append(f"HSTS header found: {hsts}")
                result["status"] = "ok"
                result["summary"] = "HTTPS is enabled and HSTS header is present."
            else:
                lines.append("HSTS header (Strict-Transport-Security) not found.")
                lines.append("")
                lines.append("Typical strong HSTS example header:")
                lines.append("  Strict-Transport-Security: max-age=31536000; includeSubDomains; preload")
                result["status"] = "warn"
                result["summary"] = "HTTPS is enabled but HSTS header is missing. Consider enabling HSTS."

        result["details"] = "\n".join(lines)
    except Exception as e:
        result["status"] = "error"
        result["summary"] = "Could not verify HTTPS/TLS and HSTS."
        result["details"] = f"Error: {e}"
    return result


def plugin_tech_fingerprint(target):
    """Tech Fingerprint (heuristic only)."""
    name = "Tech Fingerprint (Informational)"
    result = {"name": name, "status": "warn", "summary": "", "details": ""}

    try:
        resp = requests.get(target, timeout=10)
        html = resp.text.lower()

        tech_hits = []
        checks = {
            "WordPress": "wp-content",
            "Cloudflare": "cloudflare",
            "jQuery": "jquery",
            "React": "react",
            "Vue.js": "vue.js",
            "Angular": "angular",
            "Bootstrap": "bootstrap",
            "Django": "csrfmiddlewaretoken",
        }

        for tech, marker in checks.items():
            if marker in html:
                tech_hits.append(tech)

        lines = []
        if tech_hits:
            result["status"] = "ok"
            result["summary"] = "Detected possible technologies: " + ", ".join(tech_hits)
            lines.append("Possible technologies detected (heuristic only):")
            for t in tech_hits:
                lines.append(" - " + t)
        else:
            result["status"] = "warn"
            result["summary"] = "Could not detect common technologies (may be custom or obfuscated)."
            lines.append("No simple fingerprints found for standard stacks.")

        result["details"] = "\n".join(lines)
    except Exception as e:
        result["status"] = "error"
        result["summary"] = "Could not fingerprint technologies."
        result["details"] = f"Error: {e}"
    return result


def plugin_robots_txt(target):
    """Check /robots.txt and show preview."""
    name = "robots.txt"
    result = {"name": name, "status": "warn", "summary": "", "details": ""}

    try:
        parsed = urlparse(target)
        base = f"{parsed.scheme}://{parsed.netloc}"
        robots_url = base + "/robots.txt"

        resp = requests.get(robots_url, timeout=6)
        if resp.status_code == 200:
            result["status"] = "ok"
            result["summary"] = "robots.txt is available."
            content_preview = "\n".join(resp.text.splitlines()[:40])
            result["details"] = f"URL: {robots_url}\nStatus: 200 OK\n\nPreview:\n{content_preview}"
        else:
            result["status"] = "warn"
            result["summary"] = f"robots.txt returned HTTP {resp.status_code}."
            result["details"] = f"URL: {robots_url}\nStatus: {resp.status_code}"
    except Exception as e:
        result["status"] = "error"
        result["summary"] = "Could not fetch robots.txt."
        result["details"] = f"Error: {e}"
    return result


def plugin_common_ports_scan(target):
    """Basic TCP Port Visibility (simple TCP connect)."""
    name = "Basic TCP Port Visibility (Nmap-inspired)"
    result = {"name": name, "status": "warn", "summary": "", "details": ""}

    try:
        parsed = urlparse(target)
        host = parsed.hostname
        if not host:
            result["status"] = "error"
            result["summary"] = "Could not parse hostname for port scan."
            result["details"] = f"Invalid target URL: {target}"
            return result

        ip_addr = socket.gethostbyname(host)

        common_ports = [
            21, 22, 23, 25, 53,
            80, 110, 143,
            443,
            465, 587, 993, 995,
            3306, 5432, 6379,
            8080, 8443,
        ]

        open_ports = []
        lines = [
            f"Host: {host}",
            f"IP: {ip_addr}",
            "",
            "Performing simple TCP connect scan on selected common ports.",
            "This is inspired by Nmap port scanning but only uses normal sockets.",
            "",
        ]

        for port in common_ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1.0)
                res = sock.connect_ex((ip_addr, port))
                sock.close()
                if res == 0:
                    open_ports.append(port)
                    lines.append(f"OPEN  : {port}/tcp")
                else:
                    lines.append(f"CLOSED: {port}/tcp")
            except Exception as inner_e:
                lines.append(f"ERROR : {port}/tcp ({inner_e})")

        if open_ports:
            result["status"] = "warn"
            ports_str = ", ".join(str(p) for p in open_ports)
            result["summary"] = f"Open common ports detected: {ports_str}"
        else:
            result["status"] = "ok"
            result["summary"] = "No checked common ports responded on this basic TCP test."

        result["details"] = "\n".join(lines)
    except Exception as e:
        result["status"] = "error"
        result["summary"] = "Could not perform port visibility check."
        result["details"] = f"Error: {e}"
    return result


def plugin_cookie_security(target):
    """Check Secure/HttpOnly/SameSite flags."""
    name = "Cookie Security Flags"
    result = {"name": name, "status": "warn", "summary": "", "details": ""}

    try:
        resp = requests.get(target, timeout=8)
        set_cookie_headers = [
            v for (k, v) in resp.headers.items() if k.lower() == "set-cookie"
        ]

        lines = []
        if not set_cookie_headers:
            result["status"] = "ok"
            result["summary"] = "No Set-Cookie headers detected in this response."
            result["details"] = "The response did not set any cookies."
            return result

        lines.append("Raw Set-Cookie headers:")
        for h in set_cookie_headers:
            lines.append(f"  {h}")
        lines.append("")

        secure_count = 0
        httponly_count = 0
        samesite_count = 0

        for header_value in set_cookie_headers:
            lower = header_value.lower()
            if "secure" in lower:
                secure_count += 1
            if "httponly" in lower:
                httponly_count += 1
            if "samesite" in lower:
                samesite_count += 1

        lines.append(f"Cookies with Secure flag   : {secure_count}")
        lines.append(f"Cookies with HttpOnly flag : {httponly_count}")
        lines.append(f"Cookies with SameSite flag : {samesite_count}")

        if secure_count == 0 or httponly_count == 0:
            result["status"] = "warn"
            result["summary"] = "Some cookies may be missing Secure/HttpOnly/SameSite flags."
        else:
            result["status"] = "ok"
            result["summary"] = "Cookies appear to use standard security flags."

        result["details"] = "\n".join(lines)
    except Exception as e:
        result["status"] = "error"
        result["summary"] = "Could not inspect cookie security."
        result["details"] = f"Error: {e}"
    return result


def plugin_performance(target):
    """Basic Performance: response time + size."""
    name = "Basic Performance (Informational)"
    result = {"name": name, "status": "ok", "summary": "", "details": ""}

    try:
        start = time.time()
        resp = requests.get(target, timeout=10)
        elapsed = time.time() - start
        elapsed_ms = int(elapsed * 1000)
        size_bytes = len(resp.content)

        lines = [
            f"URL: {target}",
            f"Response time (approx): {elapsed_ms} ms",
            f"Content size (approx): {size_bytes} bytes",
        ]

        if elapsed_ms > 2000:
            result["status"] = "warn"
            result["summary"] = f"Page response seems slow (~{elapsed_ms} ms)."
        else:
            result["status"] = "ok"
            result["summary"] = f"Page responded in ~{elapsed_ms} ms (basic informational check)."

        result["details"] = "\n".join(lines)
    except Exception as e:
        result["status"] = "error"
        result["summary"] = "Could not measure basic performance."
        result["details"] = f"Error: {e}"
    return result


def plugin_raw_headers(target):
    """Show all HTTP response headers."""
    name = "Raw Response Headers (Informational)"
    result = {"name": name, "status": "ok", "summary": "", "details": ""}

    try:
        resp = requests.get(target, timeout=8)
        lines = [
            f"URL: {target}",
            f"Status code: {resp.status_code}",
            "",
            "Response headers:",
        ]

        for k, v in resp.headers.items():
            lines.append(f"  {k}: {v}")

        result["summary"] = "Collected raw response headers for inspection."
        result["details"] = "\n".join(lines)
    except Exception as e:
        result["status"] = "error"
        result["summary"] = "Could not fetch raw response headers."
        result["details"] = f"Error: {e}"

    return result


# -------- Built-in plugin registry -------- #

BUILTIN_PLUGINS = [
    {
        "id": "basic_info",
        "name": "Basic Site Check",
        "short": "Check if the site is reachable and get basic info.",
        "description": "Normal HTTP request, checks status code, resolved IP, final URL, server header.",
        "category": "Core",
        "default_enabled": True,
    },
    {
        "id": "security_headers",
        "name": "Security Headers",
        "short": "Check for important HTTP security headers.",
        "description": "Looks for CSP, HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy.",
        "category": "Security",
        "default_enabled": True,
    },
    {
        "id": "tls_https",
        "name": "HTTPS / TLS & HSTS",
        "short": "Check HTTPS usage and if HSTS is enabled.",
        "description": "Verifies HTTPS and presence of Strict-Transport-Security (HSTS) header.",
        "category": "Security",
        "default_enabled": True,
    },
    {
        "id": "common_ports",
        "name": "Basic TCP Port Visibility (Nmap-inspired)",
        "short": "Simple TCP connect scan on common ports.",
        "description": "Resolves the host and attempts TCP connect to common ports (22, 80, 443, etc.).",
        "category": "Network",
        "default_enabled": False,
    },
    {
        "id": "cookie_security",
        "name": "Cookie Security Flags",
        "short": "Check if cookies use Secure/HttpOnly/SameSite.",
        "description": "Inspects Set-Cookie headers to see whether common security flags are set.",
        "category": "Security",
        "default_enabled": False,
    },
    {
        "id": "robots_txt",
        "name": "robots.txt",
        "short": "Check if robots.txt exists and preview it.",
        "description": "Fetches /robots.txt and shows a short preview.",
        "category": "Info",
        "default_enabled": False,
    },
    {
        "id": "tech_fingerprint",
        "name": "Tech Fingerprint (Informational)",
        "short": "Guess framework / platform from HTML.",
        "description": "Heuristically guesses technologies (WordPress, React, Django, etc.) from HTML.",
        "category": "Info",
        "default_enabled": False,
    },
    {
        "id": "performance",
        "name": "Basic Performance (Informational)",
        "short": "Measure response time and approximate size.",
        "description": "Measures simple response time and approximate body size.",
        "category": "Info",
        "default_enabled": False,
    },
    {
        "id": "raw_headers",
        "name": "Raw Response Headers (Informational)",
        "short": "Show all HTTP response headers from the server.",
        "description": "Makes one HTTP request and prints all response headers.",
        "category": "Info",
        "default_enabled": False,
    },
]

BUILTIN_PLUGIN_MAP = {
    "basic_info": plugin_basic_info,
    "security_headers": plugin_security_headers,
    "tls_https": plugin_tls_https,
    "common_ports": plugin_common_ports_scan,
    "cookie_security": plugin_cookie_security,
    "robots_txt": plugin_robots_txt,
    "tech_fingerprint": plugin_tech_fingerprint,
    "performance": plugin_performance,
    "raw_headers": plugin_raw_headers,
}


def get_all_plugins():
    """Built-in + custom plugins list."""
    return BUILTIN_PLUGINS + CUSTOM_PLUGINS


def get_default_plugin_ids():
    """IDs of plugins with default_enabled=True."""
    ids = []
    for p in get_all_plugins():
        if p.get("default_enabled"):
            ids.append(p["id"])
    return ids


# ----------------- Theme + year ----------------- #

@app.context_processor
def inject_theme_and_year():
    theme = request.cookies.get("theme", "dark")
    if theme not in ("dark", "light"):
        theme = "dark"
    current_year = datetime.now().year
    return {"current_theme": theme, "current_year": current_year}


@app.route("/theme/<mode>")
def set_theme(mode):
    if mode not in ("dark", "light"):
        mode = "dark"
    redirect_target = request.referrer or url_for("dashboard")
    resp = redirect(redirect_target)
    resp.set_cookie("theme", mode, max_age=60 * 60 * 24 * 365)
    return resp


# ----------------- Routes ----------------- #

@app.route("/")
def root():
    return redirect(url_for("dashboard"))


@app.route("/dashboard")
def dashboard():
    scans = []
    for sid, data in SCAN_RESULTS.items():
        entry = data.copy()
        entry["id"] = sid
        scans.append(entry)
    scans.sort(key=lambda x: x["timestamp"], reverse=True)

    total_scans = len(scans)
    ok_count = sum(1 for s in scans if s["overall_status"] == "ok")
    warn_count = sum(1 for s in scans if s["overall_status"] == "warn")
    error_count = sum(1 for s in scans if s["overall_status"] == "error")

    return render_template(
        "dashboard.html",
        scans=scans,
        total_scans=total_scans,
        ok_count=ok_count,
        warn_count=warn_count,
        error_count=error_count,
    )


@app.route("/scan/new")
def scan_form():
    return render_template("scan_form.html", plugins=get_all_plugins())


@app.route("/scan", methods=["POST"])
def run_scan():
    target = request.form.get("target", "").strip()
    if not target:
        return redirect(url_for("scan_form"))

    target_norm = normalize_url(target)
    selected_plugin_ids = request.form.getlist("plugins")

    if not selected_plugin_ids:
        selected_plugin_ids = get_default_plugin_ids()

    scan_id = str(uuid.uuid4())
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    plugin_results = []
    for pid in selected_plugin_ids:
        if pid in BUILTIN_PLUGIN_MAP:
            func = BUILTIN_PLUGIN_MAP[pid]
            plugin_results.append(func(target_norm))
        elif pid.startswith("custom_"):
            plugin_results.append(run_custom_keyword_plugin(pid, target_norm))
        # unknown ids ignored

    overall_status = compute_overall_status(plugin_results)

    scan_data = {
        "target": target_norm,
        "timestamp": timestamp,
        "results": plugin_results,
        "overall_status": overall_status,
        "plugin_count": len(plugin_results),
    }
    SCAN_RESULTS[scan_id] = scan_data

    print("=== New scan stored ===")
    print("ID:", scan_id, "Target:", target_norm, "Plugins:", len(plugin_results))

    return redirect(url_for("view_report", scan_id=scan_id))


@app.route("/report/<scan_id>")
def view_report(scan_id):
    scan = SCAN_RESULTS.get(scan_id)
    if not scan:
        return "Scan not found", 404

    scan_with_id = scan.copy()
    scan_with_id["id"] = scan_id
    return render_template("report.html", scan=scan_with_id)


@app.route("/report/<scan_id>/download")
def download_report_html(scan_id):
    scan = SCAN_RESULTS.get(scan_id)
    if not scan:
        return "Scan not found", 404

    scan_with_id = scan.copy()
    scan_with_id["id"] = scan_id
    html = render_template("report.html", scan=scan_with_id)

    filename_host = urlparse(scan["target"]).hostname or "report"
    filename = f"scan-report-{filename_host}.html"

    resp = make_response(html)
    resp.headers["Content-Type"] = "text/html"
    resp.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    return resp


@app.route("/report/<scan_id>/download/pdf")
def download_report_pdf(scan_id):
    scan = SCAN_RESULTS.get(scan_id)
    if not scan:
        return "Scan not found", 404

    scan_with_id = scan.copy()
    scan_with_id["id"] = scan_id
    html = render_template("report.html", scan=scan_with_id)

    pdf_bytes = html_to_pdf(html)
    if pdf_bytes is None:
        return "Failed to generate PDF", 500

    filename_host = urlparse(scan["target"]).hostname or "report"
    filename = f"scan-report-{filename_host}.pdf"

    resp = make_response(pdf_bytes)
    resp.headers["Content-Type"] = "application/pdf"
    resp.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    return resp


@app.route("/reports")
def reports_list():
    scans = []
    for sid, data in SCAN_RESULTS.items():
        entry = data.copy()
        entry["id"] = sid
        scans.append(entry)
    scans.sort(key=lambda x: x["timestamp"], reverse=True)

    return render_template("reports.html", scans=scans)


@app.route("/about")
def about():
    return render_template("about.html", plugins=get_all_plugins())


# ------------- Plugins page: view + create custom plugins ------------- #

@app.route("/plugins", methods=["GET", "POST"])
def plugins_view():
    global CUSTOM_PLUGINS

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        short = request.form.get("short", "").strip()
        description = request.form.get("description", "").strip()
        keyword = request.form.get("keyword", "").strip()
        default_enabled = request.form.get("default_enabled") == "on"

        if name and keyword:
            pid = "custom_" + str(uuid.uuid4())[:8]
            CUSTOM_PLUGINS.append(
                {
                    "id": pid,
                    "name": name,
                    "short": short or f"Search for keyword '{keyword}' in HTML.",
                    "description": description or "Custom plugin created from the UI that searches for a keyword.",
                    "keyword": keyword,
                    "category": "Custom",
                    "default_enabled": default_enabled,
                }
            )

        return redirect(url_for("plugins_view"))

    return render_template(
        "plugins.html",
        builtin_plugins=BUILTIN_PLUGINS,
        custom_plugins=CUSTOM_PLUGINS,
    )


@app.route("/plugins/delete/<plugin_id>", methods=["POST"])
def delete_custom_plugin(plugin_id):
    global CUSTOM_PLUGINS
    CUSTOM_PLUGINS = [p for p in CUSTOM_PLUGINS if p["id"] != plugin_id]
    return redirect(url_for("plugins_view"))


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
