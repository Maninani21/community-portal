<?php
// includes/footer.php
?>
</main>
<footer class="site-footer">
  <div class="container">© <?php echo date('Y'); ?> MatchUp — built with ❤️</div>
</footer>
<script src="/public/js/permissions.js"></script>
<script src="/public/js/app.js"></script>
</body>
</html>
