</div>
    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Advanced Certificate Generation System. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>