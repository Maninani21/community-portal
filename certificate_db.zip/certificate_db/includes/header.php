<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' - ' : ''; ?>Certificate System</title>
    <link rel="stylesheet" href="/certificate_db/assets/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-brand">
                <a href="/certificate_db/admin/index.php">🎓 Certificate System - Admin</a>
            </div>
            <ul class="nav-menu">
                <li><a href="/certificate_db/admin/index.php" class="<?php echo $current_page == 'index.php' ? 'active' : ''; ?>">📊 Dashboard</a></li>
                <li><a href="/certificate_db/admin/users.php" class="<?php echo $current_page == 'users.php' ? 'active' : ''; ?>">👥 Users</a></li>
                <li><a href="/certificate_db/admin/certificates.php" class="<?php echo $current_page == 'certificates.php' ? 'active' : ''; ?>">📜 Certificates</a></li>
                <li><a href="/certificate_db/admin/templates.php" class="<?php echo $current_page == 'templates.php' ? 'active' : ''; ?>">🎨 Templates</a></li>
                <li><a href="/certificate_db/admin/bulk.php" class="<?php echo $current_page == 'bulk.php' ? 'active' : ''; ?>">⚡ Bulk Operations</a></li>
                <li><a href="/certificate_db/actions/logout.php" class="logout-btn">🚪 Logout (<?php echo htmlspecialchars($_SESSION['user_name']); ?>)</a></li>
                <li><a href="/certificate_db/verify.php" class="<?php echo $current_page == 'verify.php' ? 'active' : ''; ?>">🔍 Verify</a></li>
            </ul>
        </div>
    </nav>
    <div class="main-content">
        