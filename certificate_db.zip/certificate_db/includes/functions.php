<?php
require_once __DIR__ . '/../config/database.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['role_name']) && $_SESSION['role_name'] === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['error'] = 'Please login to access this page';
        header('Location: /certificate_db/index.php');
        exit;
    }
}

function requireAdmin() {
    if (!isLoggedIn()) {
        $_SESSION['error'] = 'Admin access required';
        header('Location: /certificate_db/admin/login.php');
        exit;
    }
    if (!isAdmin()) {
        $_SESSION['error'] = 'Access denied. Admin privileges required.';
        header('Location: /certificate_db/index.php');
        exit;
    }
}

function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

function logActivity($pdo, $user_id, $action, $description = '') {
    try {
        $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $action, $description, $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0']);
        return true;
    } catch(PDOException $e) {
        error_log("Log Error: " . $e->getMessage());
        return false;
    }
}

function generateCertificateNumber($pdo) {
    $prefix = 'CERT-' . date('Y') . '-';
    for ($i = 0; $i < 10; $i++) {
        $random = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));
        $number = $prefix . $random;
        $stmt = $pdo->prepare("SELECT id FROM certificates WHERE certificate_number = ?");
        $stmt->execute([$number]);
        if (!$stmt->fetch()) return $number;
    }
    return $prefix . strtoupper(substr(md5(microtime()), 0, 8));
}

function formatDate($date, $format = 'd M Y') {
    if (empty($date)) return 'N/A';
    return date($format, strtotime($date));
}

function formatDateTime($datetime, $format = 'd M Y H:i') {
    if (empty($datetime)) return 'N/A';
    return date($format, strtotime($datetime));
}

function ensureUploadDirectories() {
    $dirs = [
        __DIR__ . '/../uploads',
        __DIR__ . '/../uploads/certificates',
        __DIR__ . '/../uploads/templates',
        __DIR__ . '/../uploads/bulk'
    ];
    foreach ($dirs as $dir) {
        if (!file_exists($dir)) {
            mkdir($dir, 0755, true);
        }
    }
}

function generateCertificateHTML($template_html, $data) {
    $html = $template_html;
    foreach ($data as $key => $value) {
        $placeholder = '{' . $key . '}';
        $html = str_replace($placeholder, htmlspecialchars($value, ENT_QUOTES, 'UTF-8'), $html);
    }
    return $html;
}

function saveCertificateAsHTML($html, $certificate_number, $background_image = '') {
    ensureUploadDirectories();
    $filename = preg_replace('/[^A-Za-z0-9\-]/', '_', $certificate_number) . '.html';
    $filepath = __DIR__ . '/../uploads/certificates/' . $filename;
    
    $bg_style = '';
    if (!empty($background_image)) {
        $bg_style = "
        .cert-wrapper {
            background-image: url('../../" . htmlspecialchars($background_image) . "');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }";
    }
    
    $full_html = '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate - ' . htmlspecialchars($certificate_number) . '</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .cert-wrapper { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; box-shadow: 0 0 30px rgba(0,0,0,0.2); }
        ' . $bg_style . '
        .print-btn { text-align: center; margin-top: 20px; }
        .print-btn button { padding: 15px 40px; background: #1a73e8; color: white; border: none; border-radius: 8px; cursor: pointer; font-size: 16px; font-weight: bold; }
        @media print { body { background: white; padding: 0; } .cert-wrapper { box-shadow: none; } .print-btn { display: none; } }
    </style>
</head>
<body>
    <div class="cert-wrapper">' . $html . '</div>
    <div class="print-btn"><button onclick="window.print()">🖨️ Print Certificate</button></div>
</body>
</html>';
    
    file_put_contents($filepath, $full_html);
    return 'uploads/certificates/' . $filename;
}

function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function displaySuccess() {
    if (isset($_SESSION['success'])) {
        $msg = htmlspecialchars($_SESSION['success']);
        unset($_SESSION['success']);
        return '<div class="alert alert-success">' . $msg . '</div>';
    }
    return '';
}

function displayError() {
    if (isset($_SESSION['error'])) {
        $msg = htmlspecialchars($_SESSION['error']);
        unset($_SESSION['error']);
        return '<div class="alert alert-error">' . $msg . '</div>';
    }
    return '';
}

function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function isStrongPassword($password) {
    return strlen($password) >= 6;
}

// BULK USER IMPORT
function importUsersFromCSV($file, $pdo, $role_id = 2) {
    $success = 0;
    $failed = 0;
    $errors = [];
    
    if (($handle = fopen($file, "r")) !== FALSE) {
        $header = fgetcsv($handle);
        
        while (($data = fgetcsv($handle)) !== FALSE) {
            if (count($data) < 3) {
                $failed++;
                continue;
            }
            
            $name = trim($data[0]);
            $email = trim($data[1]);
            $phone = isset($data[2]) ? trim($data[2]) : '';
            $password = isset($data[3]) && !empty($data[3]) ? $data[3] : 'User@123';
            
            if (empty($name) || empty($email)) {
                $failed++;
                $errors[] = "Empty name or email for row";
                continue;
            }
            
            if (!isValidEmail($email)) {
                $failed++;
                $errors[] = "Invalid email: $email";
                continue;
            }
            
            try {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetch()) {
                    $failed++;
                    $errors[] = "Duplicate email: $email";
                    continue;
                }
                
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, password, role_id, is_active) VALUES (?, ?, ?, ?, ?, 1)");
                $stmt->execute([$name, $email, $phone, $hashed, $role_id]);
                $success++;
            } catch(Exception $e) {
                $failed++;
                $errors[] = "Error for $email: " . $e->getMessage();
            }
        }
        fclose($handle);
    }
    
    return ['success' => $success, 'failed' => $failed, 'errors' => $errors];
}

// BULK CERTIFICATE GENERATION
function generateBulkCertificates($pdo, $template_id, $user_ids, $course_name, $issue_date, $issued_by) {
    $success = 0;
    $failed = 0;
    $errors = [];
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM certificate_templates WHERE id = ? AND is_active = 1");
        $stmt->execute([$template_id]);
        $template = $stmt->fetch();
        
        if (!$template) {
            return ['success' => 0, 'failed' => count($user_ids), 'errors' => ['Template not found']];
        }
        
        foreach ($user_ids as $user_id) {
            try {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND is_active = 1");
                $stmt->execute([$user_id]);
                $user = $stmt->fetch();
                
                if (!$user) {
                    $failed++;
                    $errors[] = "User ID $user_id not found";
                    continue;
                }
                
                $cert_number = generateCertificateNumber($pdo);
                
                $cert_data = [
                    'recipient_name' => $user['name'],
                    'course_name' => $course_name,
                    'issue_date' => date('F d, Y', strtotime($issue_date)),
                    'certificate_id' => $cert_number
                ];
                
                $cert_html = generateCertificateHTML($template['template_html'], $cert_data);
                $file_path = saveCertificateAsHTML($cert_html, $cert_number, $template['background_image']);
                
                $stmt = $pdo->prepare("
                    INSERT INTO certificates 
                    (certificate_number, user_id, template_id, certificate_data, file_path, issued_date, issued_by, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'active')
                ");
                $stmt->execute([
                    $cert_number,
                    $user_id,
                    $template_id,
                    json_encode($cert_data),
                    $file_path,
                    $issue_date,
                    $issued_by
                ]);
                
                $success++;
            } catch(Exception $e) {
                $failed++;
                $errors[] = "Error for user $user_id: " . $e->getMessage();
            }
        }
    } catch(Exception $e) {
        return ['success' => 0, 'failed' => count($user_ids), 'errors' => [$e->getMessage()]];
    }
    
    return ['success' => $success, 'failed' => $failed, 'errors' => $errors];
}
?>