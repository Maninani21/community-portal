<?php
session_start();
require_once 'config/database.php';

$cert_number = isset($_GET['cert']) ? trim($_GET['cert']) : '';
$certificate = null;
$error = '';

if (!empty($cert_number)) {
    try {
        $stmt = $pdo->prepare("
            SELECT c.*, u.name as user_name, u.email as user_email, t.template_name,
                   issuer.name as issuer_name
            FROM certificates c
            JOIN users u ON c.user_id = u.id
            JOIN certificate_templates t ON c.template_id = t.id
            LEFT JOIN users issuer ON c.issued_by = issuer.id
            WHERE c.certificate_number = ? AND c.status = 'active'
        ");
        $stmt->execute([$cert_number]);
        $certificate = $stmt->fetch();
        
        if ($certificate) {
            // Log verification
            $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (NULL, 'certificate_verified', ?, ?)");
            $stmt->execute(["Certificate $cert_number verified", $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0']);
        } else {
            $error = 'Certificate not found or invalid';
        }
    } catch(PDOException $e) {
        $error = 'Verification failed';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate Verification</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .verify-container {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 40px 20px;
        }
        .verify-box {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .verify-header {
            text-align: center;
            margin-bottom: 40px;
        }
        .verify-icon {
            font-size: 80px;
            margin-bottom: 20px;
        }
        .cert-details {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 30px;
            margin-top: 30px;
        }
        .detail-row {
            display: flex;
            padding: 15px 0;
            border-bottom: 1px solid #dee2e6;
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .detail-label {
            font-weight: 600;
            width: 200px;
            color: #666;
        }
        .detail-value {
            flex: 1;
            color: #333;
            font-weight: 500;
        }
        .verified-badge {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
            padding: 15px 30px;
            border-radius: 50px;
            display: inline-block;
            font-weight: bold;
            font-size: 18px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="verify-container">
        <div class="verify-box">
            <div class="verify-header">
                <h1>🔍 Certificate Verification</h1>
                <p>Verify the authenticity of certificates</p>
            </div>
            
            <form method="GET" class="advanced-form">
                <div class="form-group">
                    <label>Enter Certificate Number</label>
                    <input type="text" name="cert" class="form-control" placeholder="CERT-2025-XXXXXXXX" 
                           value="<?php echo htmlspecialchars($cert_number); ?>" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block btn-large">🔍 Verify Certificate</button>
            </form>
            
            <?php if (!empty($cert_number)): ?>
                <?php if ($certificate): ?>
                    <div style="text-align: center;">
                        <div class="verified-badge">✅ CERTIFICATE VERIFIED</div>
                    </div>
                    
                    <div class="cert-details">
                        <h3 style="margin-bottom: 20px; color: #28a745;">✓ Valid Certificate</h3>
                        
                        <div class="detail-row">
                            <div class="detail-label">Certificate Number:</div>
                            <div class="detail-value"><strong><?php echo htmlspecialchars($certificate['certificate_number']); ?></strong></div>
                        </div>
                        
                        <div class="detail-row">
                            <div class="detail-label">Recipient Name:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($certificate['user_name']); ?></div>
                        </div>
                        
                        <div class="detail-row">
                            <div class="detail-label">Email:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($certificate['user_email']); ?></div>
                        </div>
                        
                        <div class="detail-row">
                            <div class="detail-label">Template:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($certificate['template_name']); ?></div>
                        </div>
                        
                        <div class="detail-row">
                            <div class="detail-label">Issue Date:</div>
                            <div class="detail-value"><?php echo date('F d, Y', strtotime($certificate['issued_date'])); ?></div>
                        </div>
                        
                        <div class="detail-row">
                            <div class="detail-label">Issued By:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($certificate['issuer_name'] ?? 'System'); ?></div>
                        </div>
                        
                        <div class="detail-row">
                            <div class="detail-label">Status:</div>
                            <div class="detail-value">
                                <span class="badge badge-success"><?php echo strtoupper($certificate['status']); ?></span>
                            </div>
                        </div>
                        
                        <div style="margin-top: 30px; text-align: center;">
                            <a href="<?php echo htmlspecialchars($certificate['file_path']); ?>" target="_blank" 
                               class="btn btn-primary">View Certificate</a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-error" style="margin-top: 30px;">
                        <strong>❌ Certificate Not Found</strong><br>
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            
            <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
                <a href="index.php">← Back to Home</a>
            </div>
        </div>
    </div>
</body>
</html>