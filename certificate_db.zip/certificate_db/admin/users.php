<?php
$page_title = 'User Management';
require_once '../includes/header.php';

// Get all users
$stmt = $pdo->query("SELECT u.*, r.role_name FROM users u JOIN roles r ON u.role_id = r.id ORDER BY u.created_at DESC");
$users = $stmt->fetchAll();

// Get roles
$stmt = $pdo->query("SELECT * FROM roles WHERE is_active = 1");
$roles = $stmt->fetchAll();
?>

<div class="container">
    <div class="page-header">
        <h1>👥 User Management</h1>
        <div class="header-actions">
            <a href="bulk.php" class="btn btn-success">⚡ Bulk Import</a>
            <button class="btn btn-primary" onclick="openModal('addUserModal')">➕ Add User</button>
        </div>
    </div>
    
    <?php echo displaySuccess(); ?>
    <?php echo displayError(); ?>
    
    <div class="card">
        <div class="table-container">
            <table class="modern-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo $user['id']; ?></td>
                        <td><strong><?php echo htmlspecialchars($user['name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['phone'] ?? 'N/A'); ?></td>
                        <td>
                            <span class="badge badge-<?php echo $user['role_name'] === 'admin' ? 'danger' : 'info'; ?>">
                                <?php echo htmlspecialchars($user['role_name']); ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge badge-<?php echo $user['is_active'] ? 'success' : 'secondary'; ?>">
                                <?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?>
                            </span>
                        </td>
                        <td><?php echo formatDate($user['created_at']); ?></td>
                        <td>
                            <button class="btn btn-sm btn-secondary" onclick='editUser(<?php echo json_encode($user); ?>)'>Edit</button>
                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                            <a href="../actions/delete_user.php?id=<?php echo $user['id']; ?>" 
                               class="btn btn-sm btn-danger" 
                               onclick="return confirm('Delete this user?')">Delete</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add User Modal -->
<div id="addUserModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Add New User</h2>
            <span class="modal-close" onclick="closeModal('addUserModal')">&times;</span>
        </div>
        <form action="../actions/save_user.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
            <div class="form-row">
                <div class="form-group">
                    <label>Name *</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Phone</label>
                    <input type="tel" name="phone" class="form-control">
                </div>
                <div class="form-group">
                    <label>Role *</label>
                    <select name="role_id" class="form-control" required>
                        <?php foreach ($roles as $role): ?>
                        <option value="<?php echo $role['id']; ?>"><?php echo $role['role_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>Address</label>
                <input type="text" name="address" class="form-control">
            </div>
            <div class="form-group">
                <label>Password *</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="is_active" checked> Active
                </label>
            </div>
            <button type="submit" class="btn btn-primary">Create User</button>
        </form>
    </div>
</div>

<!-- Edit User Modal -->
<div id="editUserModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Edit User</h2>
            <span class="modal-close" onclick="closeModal('editUserModal')">&times;</span>
        </div>
        <form action="../actions/save_user.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
            <input type="hidden" id="edit_user_id" name="user_id">
            <div class="form-row">
                <div class="form-group">
                    <label>Name *</label>
                    <input type="text" id="edit_name" name="name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" id="edit_email" name="email" class="form-control" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Phone</label>
                    <input type="tel" id="edit_phone" name="phone" class="form-control">
                </div>
                <div class="form-group">
                    <label>Role *</label>
                    <select id="edit_role_id" name="role_id" class="form-control" required>
                        <?php foreach ($roles as $role): ?>
                        <option value="<?php echo $role['id']; ?>"><?php echo $role['role_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>Address</label>
                <input type="text" id="edit_address" name="address" class="form-control">
            </div>
            <div class="form-group">
                <label>Password (leave blank to keep current)</label>
                <input type="password" name="password" class="form-control">
            </div>
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" id="edit_is_active" name="is_active"> Active
                </label>
            </div>
            <button type="submit" class="btn btn-primary">Update User</button>
        </form>
    </div>
</div>

<script>
function openModal(id) { document.getElementById(id).classList.add('active'); }
function closeModal(id) { document.getElementById(id).classList.remove('active'); }
function editUser(user) {
    document.getElementById('edit_user_id').value = user.id;
    document.getElementById('edit_name').value = user.name;
    document.getElementById('edit_email').value = user.email;
    document.getElementById('edit_phone').value = user.phone || '';
    document.getElementById('edit_address').value = user.address || '';
    document.getElementById('edit_role_id').value = user.role_id;
    document.getElementById('edit_is_active').checked = user.is_active == 1;
    openModal('editUserModal');
}
window.onclick = function(e) {
    if (e.target.classList.contains('modal')) closeModal(e.target.id);
}
</script>

<?php require_once '../includes/footer.php'; ?>
