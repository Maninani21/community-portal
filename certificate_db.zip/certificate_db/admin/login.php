<?php
session_start();

if (isset($_SESSION['user_id']) && isset($_SESSION['role_name']) && $_SESSION['role_name'] === 'admin') {
    header('Location: index.php');
    exit;
}

$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Certificate System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="login-container admin-bg">
        <div class="login-box admin-login-box">
            <div class="admin-badge">🔐 ADMINISTRATOR ACCESS</div>
            <div class="login-header">
                <h1>🎓 Certificate System</h1>
                <p>Secure Admin Portal</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <form action="../actions/admin_login.php" method="POST" class="advanced-form">
                <div class="form-group">
                    <label for="email">📧 Admin Email</label>
                    <input type="email" id="email" name="email" class="form-control" required autofocus>
                </div>
                
                <div class="form-group">
                    <label for="password">🔒 Admin Password</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember">
                        Remember this device
                    </label>
                </div>
                
                <button type="submit" class="btn btn-danger btn-block btn-large">Admin Login</button>
            </form>
            
            <div class="admin-info">
                <div class="info-box">
                    <strong>⚠️ Security Notice</strong>
                    <p>Unauthorized access attempts will be logged and reported.</p>
                </div>
                
                <div class="default-creds">
                    <p><strong>Default Admin Credentials:</strong></p>
                    <p>Email: <code>admin@certificate.com</code></p>
                    <p>Password: <code>Admin@123</code></p>
                </div>
            </div>
            
            <div class="login-footer">
                <p>Not an administrator? <a href="../index.php">User Portal</a></p>
            </div>
        </div>
    </div>
</body>
</html>
