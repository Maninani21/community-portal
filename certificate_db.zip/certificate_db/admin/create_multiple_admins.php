<?php
/**
 * create_multiple_admins.php
 *
 * Usage (browser):
 *  http://localhost/certificate_db/admin/create_multiple_admins.php?n=5&prefix=admin
 *
 * Usage (CLI):
 *  php create_multiple_admins.php 5 admin
 *
 * The script will:
 *  - create admins table if not exists
 *  - insert N admins with emails like prefix1@certificate.com, prefix2@certificate.com ...
 *  - generate secure random passwords for each
 *  - print credentials and save them to new_admins.csv
 */

// ---------------------- CONFIG: set these to match your environment ----------------------
$DB_HOST = '127.0.0.1';
$DB_NAME = 'certificate_db';
$DB_USER = 'root';
$DB_PASS = '';            // change if needed
$DB_CHARSET = 'utf8mb4';

// default email domain and prefix
$DEFAULT_DOMAIN = 'certificate.com';
$DEFAULT_PREFIX = 'adminnew'; // emails will be adminnew1@certificate.com, adminnew2@certificate.com...
// -----------------------------------------------------------------------------------------

// get N and prefix from CLI or GET/POST
if (php_sapi_name() === 'cli') {
    $argc_n = $argv[1] ?? null;
    $argc_prefix = $argv[2] ?? null;
    $n = is_numeric($argc_n) ? (int)$argc_n : 5;
    $prefix = $argc_prefix ?: $DEFAULT_PREFIX;
} else {
    $n = isset($_GET['n']) && is_numeric($_GET['n']) ? (int)$_GET['n'] : 5;
    $prefix = isset($_GET['prefix']) && $_GET['prefix'] !== '' ? preg_replace('/[^a-z0-9_\\-]/i','', $_GET['prefix']) : $DEFAULT_PREFIX;
}

// basic validation
if ($n < 1) $n = 1;
if ($n > 500) $n = 500; // safety cap

// ---------- helper functions ----------
function gen_password($length = 12) {
    // create a password with mixed chars and at least one upper, lower, digit and special
    $lower = 'abcdefghjkmnpqrstuvwxyz'; // avoid ambiguous i,l
    $upper = 'ABCDEFGHJKMNPQRSTUVWXYZ';
    $digits = '23456789'; // avoid 0,1
    $special = '!@#$%*-_+=';
    $all = $lower . $upper . $digits . $special;

    // ensure each category present
    $password = '';
    $password .= $lower[random_int(0, strlen($lower)-1)];
    $password .= $upper[random_int(0, strlen($upper)-1)];
    $password .= $digits[random_int(0, strlen($digits)-1)];
    $password .= $special[random_int(0, strlen($special)-1)];

    for ($i = 4; $i < $length; $i++) {
        $password .= $all[random_int(0, strlen($all)-1)];
    }

    // shuffle
    $pw = str_shuffle($password);
    return $pw;
}

// ---------- connect using PDO ----------
$dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset={$DB_CHARSET}";
try {
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Exception $e) {
    // if PDO fails, show clear instructions
    $msg = "DB connection failed: " . $e->getMessage() . PHP_EOL;
    if (php_sapi_name() === 'cli') {
        echo $msg;
    } else {
        echo "<pre>" . htmlspecialchars($msg) . "</pre>";
    }
    exit;
}

// ---------- create admins table if not exists ----------
$createSql = <<<SQL
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(100) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SQL;

$pdo->exec($createSql);

// ---------- insert N admins ----------
$insertStmt = $pdo->prepare("INSERT INTO admins (email, password_hash, name) VALUES (:email, :ph, :name)");

// collect created records for output and CSV
$created = [];

for ($i = 1; $i <= $n; $i++) {
    // generate email (avoid collisions by appending random suffix if needed)
    $emailBase = "{$prefix}{$i}@{$DEFAULT_DOMAIN}";
    $email = $emailBase;
    $attempt = 0;
    while (true) {
        // check if exists
        $check = $pdo->prepare("SELECT id FROM admins WHERE email = :email LIMIT 1");
        $check->execute([':email' => $email]);
        if (!$check->fetch()) break; // free to use
        // collision -> add small random suffix
        $attempt++;
        $email = "{$prefix}{$i}_{$attempt}@{$DEFAULT_DOMAIN}";
        if ($attempt > 10) {
            // extremely unlikely — fallback to random email
            $email = "{$prefix}{$i}_" . bin2hex(random_bytes(3)) . "@{$DEFAULT_DOMAIN}";
            break;
        }
    }

    $plainPassword = gen_password(12);
    $hash = password_hash($plainPassword, PASSWORD_DEFAULT);
    $name = "Admin {$i}";

    try {
        $insertStmt->execute([
            ':email' => $email,
            ':ph' => $hash,
            ':name' => $name
        ]);
        $created[] = ['email' => $email, 'password' => $plainPassword, 'name' => $name];
    } catch (Exception $ex) {
        // skip and continue, but record failure
        $created[] = ['email' => $email, 'password' => null, 'name' => $name, 'error' => $ex->getMessage()];
    }
}

// ---------- output results ----------
$csvPath = __DIR__ . '/new_admins.csv';
$fp = fopen($csvPath, 'w');
fputcsv($fp, ['email','password','name','note']);

if (php_sapi_name() === 'cli') {
    echo PHP_EOL . "Created " . count($created) . " admin accounts." . PHP_EOL;
    echo str_repeat('-',60) . PHP_EOL;
    foreach ($created as $row) {
        fputcsv($fp, [$row['email'], $row['password'] ?? '', $row['name'], $row['error'] ?? '']);
        if (isset($row['error'])) {
            echo "[ERROR] {$row['email']} -> {$row['error']}" . PHP_EOL;
        } else {
            echo "Email: {$row['email']}   Password: {$row['password']}" . PHP_EOL;
        }
    }
    fclose($fp);
    echo PHP_EOL . "CSV saved to: {$csvPath}" . PHP_EOL;
} else {
    echo "<h2>Created " . count($created) . " admin accounts</h2>";
    echo "<table border='1' cellpadding='6' style='border-collapse:collapse'>";
    echo "<tr><th>Email</th><th>Password</th><th>Name</th><th>Note</th></tr>";
    foreach ($created as $row) {
        fputcsv($fp, [$row['email'], $row['password'] ?? '', $row['name'], $row['error'] ?? '']);
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
        echo "<td>" . htmlspecialchars($row['password'] ?? '—') . "</td>";
        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
        echo "<td>" . (isset($row['error']) ? htmlspecialchars($row['error']) : '') . "</td>";
        echo "</tr>";
    }
    fclose($fp);
    echo "</table>";
    echo "<p>CSV downloaded to <strong>" . htmlspecialchars($csvPath) . "</strong> on server. Download it from your project folder.</p>";
    echo "<p>Tip: Change <code>\$DEFAULT_PREFIX</code> or pass <code>?prefix=foo&amp;n=10</code> in URL.</p>";
}
