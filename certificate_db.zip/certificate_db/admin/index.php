<?php
$page_title = 'Dashboard';
require_once '../includes/header.php';

// Get statistics
$stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE is_active = 1");
$total_users = $stmt->fetch()['count'];

$stmt = $pdo->query("SELECT COUNT(*) as count FROM certificates");
$total_certs = $stmt->fetch()['count'];

$stmt = $pdo->query("SELECT COUNT(*) as count FROM certificate_templates WHERE is_active = 1");
$total_templates = $stmt->fetch()['count'];

$stmt = $pdo->query("SELECT COUNT(*) as count FROM certificates WHERE MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())");
$certs_this_month = $stmt->fetch()['count'];

// Recent certificates
$stmt = $pdo->query("SELECT c.*, u.name as user_name, t.template_name FROM certificates c JOIN users u ON c.user_id = u.id JOIN certificate_templates t ON c.template_id = t.id ORDER BY c.created_at DESC LIMIT 5");
$recent_certs = $stmt->fetchAll();

// Recent activities
$stmt = $pdo->query("SELECT a.*, u.name as user_name FROM activity_logs a LEFT JOIN users u ON a.user_id = u.id ORDER BY a.created_at DESC LIMIT 10");
$activities = $stmt->fetchAll();
?>

<div class="container">
    <div class="dashboard-header">
        <h1>📊 Admin Dashboard</h1>
        <p>Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</p>
    </div>
    
    <?php echo displaySuccess(); ?>
    <?php echo displayError(); ?>
    
    <div class="stats-grid">
        <div class="stat-card blue">
            <div class="stat-icon">👥</div>
            <div class="stat-info">
                <h3>Total Users</h3>
                <p class="stat-number"><?php echo $total_users; ?></p>
            </div>
        </div>
        
        <div class="stat-card green">
            <div class="stat-icon">📜</div>
            <div class="stat-info">
                <h3>Total Certificates</h3>
                <p class="stat-number"><?php echo $total_certs; ?></p>
            </div>
        </div>
        
        <div class="stat-card orange">
            <div class="stat-icon">🎨</div>
            <div class="stat-info">
                <h3>Active Templates</h3>
                <p class="stat-number"><?php echo $total_templates; ?></p>
            </div>
        </div>
        
        <div class="stat-card purple">
            <div class="stat-icon">📈</div>
            <div class="stat-info">
                <h3>This Month</h3>
                <p class="stat-number"><?php echo $certs_this_month; ?></p>
            </div>
        </div>
    </div>
    
    <div class="dashboard-grid">
        <div class="dashboard-card">
            <div class="card-header">
                <h2>📜 Recent Certificates</h2>
                <a href="certificates.php" class="btn btn-sm btn-primary">View All</a>
            </div>
            <div class="table-container">
                <table class="modern-table">
                    <thead>
                        <tr>
                            <th>Certificate #</th>
                            <th>User</th>
                            <th>Template</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recent_certs)): ?>
                            <tr><td colspan="4" class="text-center">No certificates yet</td></tr>
                        <?php else: ?>
                            <?php foreach ($recent_certs as $cert): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($cert['certificate_number']); ?></strong></td>
                                <td><?php echo htmlspecialchars($cert['user_name']); ?></td>
                                <td><?php echo htmlspecialchars($cert['template_name']); ?></td>
                                <td><?php echo formatDate($cert['issued_date']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="dashboard-card">
            <div class="card-header">
                <h2>📋 Recent Activity</h2>
            </div>
            <div class="activity-list">
                <?php if (empty($activities)): ?>
                    <p class="text-center">No activities yet</p>
                <?php else: ?>
                    <?php foreach ($activities as $activity): ?>
                    <div class="activity-item">
                        <div class="activity-icon">📌</div>
                        <div class="activity-details">
                            <p class="activity-user"><?php echo htmlspecialchars($activity['user_name'] ?? 'System'); ?></p>
                            <p class="activity-action"><?php echo htmlspecialchars($activity['description']); ?></p>
                            <p class="activity-time"><?php echo formatDateTime($activity['created_at']); ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
