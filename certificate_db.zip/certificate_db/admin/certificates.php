<?php
$page_title = 'Certificate Management';
require_once '../includes/header.php';

$stmt = $pdo->query("SELECT c.*, u.name as user_name, t.template_name FROM certificates c JOIN users u ON c.user_id = u.id JOIN certificate_templates t ON c.template_id = t.id ORDER BY c.created_at DESC");
$certificates = $stmt->fetchAll();

$stmt = $pdo->query("SELECT id, name, email FROM users WHERE is_active = 1 ORDER BY name");
$users = $stmt->fetchAll();

$stmt = $pdo->query("SELECT id, template_name, variables FROM certificate_templates WHERE is_active = 1");
$templates = $stmt->fetchAll();
?>

<div class="container">
    <div class="page-header">
        <h1>📜 Certificate Management</h1>
        <div class="header-actions">
            <a href="bulk.php" class="btn btn-success">⚡ Bulk Generate</a>
            <button class="btn btn-primary" onclick="openModal('generateModal')">➕ Generate Certificate</button>
        </div>
    </div>
    
    <?php echo displaySuccess(); ?>
    <?php echo displayError(); ?>
    
    <div class="card">
        <div class="table-container">
            <table class="modern-table">
                <thead>
                    <tr>
                        <th>Certificate #</th>
                        <th>User</th>
                        <th>Template</th>
                        <th>Issue Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($certificates)): ?>
                    <tr><td colspan="6" class="text-center">No certificates generated yet</td></tr>
                    <?php else: ?>
                    <?php foreach ($certificates as $cert): ?>
                    <tr>
                        <td><strong><?php echo htmlspecialchars($cert['certificate_number']); ?></strong></td>
                        <td><?php echo htmlspecialchars($cert['user_name']); ?></td>
                        <td><?php echo htmlspecialchars($cert['template_name']); ?></td>
                        <td><?php echo formatDate($cert['issued_date']); ?></td>
                        <td><span class="badge badge-success"><?php echo $cert['status']; ?></span></td>
                        <td>
                            <a href="../<?php echo $cert['file_path']; ?>" target="_blank" class="btn btn-sm btn-primary">View</a>
                            <a href="../actions/delete_certificate.php?id=<?php echo $cert['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="generateModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Generate Certificate</h2>
            <span class="modal-close" onclick="closeModal('generateModal')">&times;</span>
        </div>
        <form action="../actions/generate_certificate.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
            <div class="form-group">
                <label>User *</label>
                <select name="user_id" class="form-control" required>
                    <option value="">Select User</option>
                    <?php foreach ($users as $user): ?>
                    <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['name']) . ' (' . $user['email'] . ')'; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Template *</label>
                <select name="template_id" id="template_select" class="form-control" required onchange="loadVariables()">
                    <option value="">Select Template</option>
                    <?php foreach ($templates as $template): ?>
                    <option value="<?php echo $template['id']; ?>" data-variables="<?php echo htmlspecialchars($template['variables']); ?>">
                        <?php echo htmlspecialchars($template['template_name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div id="variables_container"></div>
            <div class="form-group">
                <label>Issue Date *</label>
                <input type="date" name="issue_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <button type="submit" class="btn btn-success">Generate</button>
        </form>
    </div>
</div>

<script>
function openModal(id) { document.getElementById(id).classList.add('active'); }
function closeModal(id) { document.getElementById(id).classList.remove('active'); }
function loadVariables() {
    const select = document.getElementById('template_select');
    const option = select.options[select.selectedIndex];
    const variables = option.getAttribute('data-variables');
    const container = document.getElementById('variables_container');
    container.innerHTML = '';
    
    if (variables) {
        const vars = variables.split(',');
        vars.forEach(v => {
            if (v.trim() && v.trim() !== 'certificate_id' && v.trim() !== 'issue_date') {
                const div = document.createElement('div');
                div.className = 'form-group';
                div.innerHTML = `
                    <label>${v.replace(/_/g, ' ').toUpperCase()} *</label>
                    <input type="text" name="variables[${v.trim()}]" class="form-control" required>
                `;
                container.appendChild(div);
            }
        });
    }
}
</script>

<?php require_once '../includes/footer.php'; ?>