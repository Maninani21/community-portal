<?php
$page_title = 'Bulk Operations';
require_once '../includes/header.php';

// Get all users for bulk certificate generation
$stmt = $pdo->query("SELECT id, name, email FROM users WHERE role_id = 2 AND is_active = 1 ORDER BY name");
$users = $stmt->fetchAll();

// Get templates
$stmt = $pdo->query("SELECT id, template_name FROM certificate_templates WHERE is_active = 1 ORDER BY template_name");
$templates = $stmt->fetchAll();

// Get roles for bulk user import
$stmt = $pdo->query("SELECT id, role_name FROM roles WHERE is_active = 1 ORDER BY role_name");
$roles = $stmt->fetchAll();
?>

<div class="container">
    <div class="page-header">
        <h1>⚡ Bulk Operations</h1>
        <p>Import multiple users and generate certificates in bulk</p>
    </div>
    
    <?php echo displaySuccess(); ?>
    <?php echo displayError(); ?>
    
    <div class="bulk-grid">
        <!-- BULK USER IMPORT -->
        <div class="bulk-card">
            <div class="bulk-header">
                <div class="bulk-icon">📥</div>
                <h2>Bulk User Import</h2>
                <p>Import multiple users from CSV file</p>
            </div>
            
            <form action="../actions/bulk_import_users.php" method="POST" enctype="multipart/form-data" class="bulk-form">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="form-group">
                    <label>📄 CSV File Format:</label>
                    <div class="csv-format">
                        <code>name,email,phone,password</code>
                        <p>Example: John Doe,john@example.com,1234567890,password123</p>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="role_id">👤 Assign Role</label>
                    <select name="role_id" id="role_id" class="form-control" required>
                        <?php foreach ($roles as $role): ?>
                            <option value="<?php echo $role['id']; ?>" <?php echo $role['role_name'] == 'user' ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($role['role_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="csv_file">📂 Select CSV File</label>
                    <input type="file" name="csv_file" id="csv_file" class="form-control" accept=".csv" required>
                </div>
                
                <button type="submit" class="btn btn-success btn-block btn-large">
                    📥 Import Users
                </button>
            </form>
            
            <div class="bulk-download">
                <a href="../assets/sample_users.csv" download class="btn btn-secondary btn-sm">
                    📥 Download Sample CSV
                </a>
            </div>
        </div>
        
        <!-- BULK CERTIFICATE GENERATION -->
        <div class="bulk-card">
            <div class="bulk-header">
                <div class="bulk-icon">⚡</div>
                <h2>Bulk Certificate Generation</h2>
                <p>Generate certificates for multiple users at once</p>
            </div>
            
            <form action="../actions/bulk_generate_certificates.php" method="POST" class="bulk-form" id="bulkCertForm">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="form-group">
                    <label for="template_id">🎨 Select Template</label>
                    <select name="template_id" id="template_id" class="form-control" required>
                        <option value="">-- Select Template --</option>
                        <?php foreach ($templates as $template): ?>
                            <option value="<?php echo $template['id']; ?>">
                                <?php echo htmlspecialchars($template['template_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="course_name">📚 Course/Program Name</label>
                    <input type="text" name="course_name" id="course_name" class="form-control" required 
                           placeholder="e.g., Web Development Bootcamp">
                </div>
                
                <div class="form-group">
                    <label for="issue_date">📅 Issue Date</label>
                    <input type="date" name="issue_date" id="issue_date" class="form-control" 
                           value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>👥 Select Users (<?php echo count($users); ?> available)</label>
                    <div class="user-selection">
                        <div class="select-all-bar">
                            <label class="checkbox-label">
                                <input type="checkbox" id="select_all">
                                <strong>Select All Users</strong>
                            </label>
                            <span id="selected_count" class="badge">0 selected</span>
                        </div>
                        
                        <div class="user-list">
                            <?php foreach ($users as $user): ?>
                            <label class="user-item">
                                <input type="checkbox" name="user_ids[]" value="<?php echo $user['id']; ?>" class="user-checkbox">
                                <div class="user-info">
                                    <strong><?php echo htmlspecialchars($user['name']); ?></strong>
                                    <small><?php echo htmlspecialchars($user['email']); ?></small>
                                </div>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-success btn-block btn-large">
                    ⚡ Generate Certificates
                </button>
            </form>
        </div>
    </div>
    
    <!-- INSTRUCTIONS -->
    <div class="instructions-card">
        <h3>📖 Instructions</h3>
        <div class="instructions-grid">
            <div class="instruction-item">
                <span class="instruction-number">1</span>
                <div>
                    <h4>Bulk User Import</h4>
                    <p>Prepare a CSV file with user details (name, email, phone, password). If password is not provided, default password 'User@123' will be used.</p>
                </div>
            </div>
            
            <div class="instruction-item">
                <span class="instruction-number">2</span>
                <div>
                    <h4>Bulk Certificate Generation</h4>
                    <p>Select a template, enter course name, choose users, and click generate. Certificates will be created for all selected users simultaneously.</p>
                </div>
            </div>
            
            <div class="instruction-item">
                <span class="instruction-number">3</span>
                <div>
                    <h4>Best Practices</h4>
                    <p>For large batches (100+ users), consider splitting into smaller groups. Always verify user data before importing.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Select all functionality
document.getElementById('select_all').addEventListener('change', function() {
    const checkboxes = document.querySelectorAll('.user-checkbox');
    checkboxes.forEach(cb => cb.checked = this.checked);
    updateCount();
});

// Update selected count
const userCheckboxes = document.querySelectorAll('.user-checkbox');
userCheckboxes.forEach(cb => {
    cb.addEventListener('change', updateCount);
});

function updateCount() {
    const checked = document.querySelectorAll('.user-checkbox:checked').length;
    document.getElementById('selected_count').textContent = checked + ' selected';
}

// Form validation
document.getElementById('bulkCertForm').addEventListener('submit', function(e) {
    const checked = document.querySelectorAll('.user-checkbox:checked').length;
    if (checked === 0) {
        e.preventDefault();
        alert('Please select at least one user!');
        return false;
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>
