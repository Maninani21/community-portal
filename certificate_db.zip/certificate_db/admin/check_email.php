<?php
session_start();
require_once '../config/database.php'; // ✅ adjust path if needed

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Clean inputs
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($email) || empty($password)) {
        echo "⚠️ Please enter both email and password.";
        exit;
    }

    try {
        // ✅ Prepare and check email
        $stmt = $conn->prepare("SELECT id, email, password FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            echo "❌ Email not found!";
            exit;
        }

        $user = $result->fetch_assoc();

        // ✅ Verify password
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            echo "✅ Login successful!";
        } else {
            echo "❌ Wrong password!";
        }

    } catch (Exception $e) {
        echo "❌ Error: " . $e->getMessage();
    }
}
?>
