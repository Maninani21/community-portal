<?php
$page_title = 'Template Management';
require_once '../includes/header.php';

$stmt = $pdo->query("SELECT * FROM certificate_templates ORDER BY created_at DESC");
$templates = $stmt->fetchAll();
?>

<div class="container">
    <div class="page-header">
        <h1>🎨 Template Management</h1>
        <button class="btn btn-primary" onclick="openModal('addTemplateModal')">➕ Add Template</button>
    </div>
    
    <?php echo displaySuccess(); ?>
    <?php echo displayError(); ?>
    
    <div class="templates-grid">
        <?php foreach ($templates as $template): ?>
        <div class="template-card">
            <div class="template-header">
                <h3><?php echo htmlspecialchars($template['template_name']); ?></h3>
                <span class="badge badge-<?php echo $template['is_active'] ? 'success' : 'secondary'; ?>">
                    <?php echo $template['is_active'] ? 'Active' : 'Inactive'; ?>
                </span>
            </div>
            <div class="template-info">
                <p><strong>Variables:</strong> <?php echo htmlspecialchars($template['variables']); ?></p>
                <p><strong>Created:</strong> <?php echo formatDate($template['created_at']); ?></p>
            </div>
            <div class="template-actions">
                <button class="btn btn-sm btn-secondary" onclick='editTemplate(<?php echo json_encode($template); ?>)'>Edit</button>
                <a href="../actions/delete_template.php?id=<?php echo $template['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<div id="addTemplateModal" class="modal">
    <div class="modal-content" style="max-width: 900px;">
        <div class="modal-header">
            <h2>Add Template</h2>
            <span class="modal-close" onclick="closeModal('addTemplateModal')">&times;</span>
        </div>
        <form action="../actions/save_template.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
            <div class="form-group">
                <label>Template Name *</label>
                <input type="text" name="template_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Variables * (comma-separated)</label>
                <input type="text" name="variables" class="form-control" placeholder="recipient_name,course_name,issue_date" required>
            </div>
            <div class="form-group">
                <label>Template HTML *</label>
                <textarea name="template_html" class="form-control" rows="10" required></textarea>
            </div>
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="is_active" checked> Active
                </label>
            </div>
            <button type="submit" class="btn btn-primary">Create Template</button>
        </form>
    </div>
</div>

<div id="editTemplateModal" class="modal">
    <div class="modal-content" style="max-width: 900px;">
        <div class="modal-header">
            <h2>Edit Template</h2>
            <span class="modal-close" onclick="closeModal('editTemplateModal')">&times;</span>
        </div>
        <form action="../actions/save_template.php" method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
            <input type="hidden" id="edit_template_id" name="template_id">
            <div class="form-group">
                <label>Template Name *</label>
                <input type="text" id="edit_template_name" name="template_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Variables *</label>
                <input type="text" id="edit_variables" name="variables" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Template HTML *</label>
                <textarea id="edit_template_html" name="template_html" class="form-control" rows="10" required></textarea>
            </div>
            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" id="edit_is_active" name="is_active"> Active
                </label>
            </div>
            <button type="submit" class="btn btn-primary">Update Template</button>
        </form>
    </div>
</div>

<script>
function openModal(id) { document.getElementById(id).classList.add('active'); }
function closeModal(id) { document.getElementById(id).classList.remove('active'); }
function editTemplate(t) {
    document.getElementById('edit_template_id').value = t.id;
    document.getElementById('edit_template_name').value = t.template_name;
    document.getElementById('edit_variables').value = t.variables;
    document.getElementById('edit_template_html').value = t.template_html;
    document.getElementById('edit_is_active').checked = t.is_active == 1;
    openModal('editTemplateModal');
}
</script>

<?php require_once '../includes/footer.php'; ?>
