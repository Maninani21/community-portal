<?php
// create_default_admin.php
require_once __DIR__ . '/config/database.php';

$email = 'admin@certificate.com';
$password = 'Admin@123';
$name = 'Administrator';

// check if exists
$stmt = $pdo->prepare("SELECT id FROM admins WHERE email = :email");
$stmt->execute([':email' => $email]);
if ($stmt->fetch()) {
    echo "Default admin already exists.\n";
    exit;
}

// create with password_hash
$hash = password_hash($password, PASSWORD_DEFAULT);
$ins = $pdo->prepare("INSERT INTO admins (email, password_hash, name) VALUES (:email, :hash, :name)");
$ins->execute([':email' => $email, ':hash' => $hash, ':name' => $name]);

echo "Default admin created. Email: $email  Password: $password\n";
