<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    $_SESSION['error'] = 'Invalid request';
    header('Location: ../admin/templates.php');
    exit;
}

$template_id = isset($_POST['template_id']) ? (int)$_POST['template_id'] : null;
$template_name = trim($_POST['template_name'] ?? '');
$template_html = $_POST['template_html'] ?? '';
$variables = trim($_POST['variables'] ?? '');
$is_active = isset($_POST['is_active']) ? 1 : 0;

if (empty($template_name) || empty($template_html) || empty($variables)) {
    $_SESSION['error'] = 'All fields required';
    header('Location: ../admin/templates.php');
    exit;
}

try {
    if ($template_id) {
        $stmt = $pdo->prepare("UPDATE certificate_templates SET template_name=?, template_html=?, variables=?, is_active=? WHERE id=?");
        $stmt->execute([$template_name, $template_html, $variables, $is_active, $template_id]);
        $_SESSION['success'] = 'Template updated';
    } else {
        $stmt = $pdo->prepare("INSERT INTO certificate_templates (template_name, template_html, variables, is_active, created_by) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$template_name, $template_html, $variables, $is_active, $_SESSION['user_id']]);
        $_SESSION['success'] = 'Template created';
    }
    logActivity($pdo, $_SESSION['user_id'], 'save_template', "Saved template: $template_name");
} catch(PDOException $e) {
    $_SESSION['error'] = 'Failed to save template';
}

header('Location: ../admin/templates.php');
exit;
?>
