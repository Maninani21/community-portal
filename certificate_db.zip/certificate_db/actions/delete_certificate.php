<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
requireAdmin();

$cert_id = (int)($_GET['id'] ?? 0);

try {
    $stmt = $pdo->prepare("SELECT file_path FROM certificates WHERE id = ?");
    $stmt->execute([$cert_id]);
    $cert = $stmt->fetch();
    
    if ($cert && !empty($cert['file_path'])) {
        $file = __DIR__ . '/../' . $cert['file_path'];
        if (file_exists($file)) unlink($file);
    }
    
    $stmt = $pdo->prepare("DELETE FROM certificates WHERE id = ?");
    $stmt->execute([$cert_id]);
    
    logActivity($pdo, $_SESSION['user_id'], 'delete_certificate', "Deleted certificate ID: $cert_id");
    $_SESSION['success'] = 'Certificate deleted';
} catch(PDOException $e) {
    $_SESSION['error'] = 'Failed to delete certificate';
}

header('Location: ../admin/certificates.php');
exit;
?>
