<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
requireAdmin();

$user_id = (int)($_GET['id'] ?? 0);

if ($user_id == $_SESSION['user_id']) {
    $_SESSION['error'] = 'Cannot delete yourself';
    header('Location: ../admin/users.php');
    exit;
}

try {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    logActivity($pdo, $_SESSION['user_id'], 'delete_user', "Deleted user ID: $user_id");
    $_SESSION['success'] = 'User deleted';
} catch(PDOException $e) {
    $_SESSION['error'] = 'Failed to delete user';
}

header('Location: ../admin/users.php');
exit;
?>
