<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    $_SESSION['error'] = 'Invalid request';
    header('Location: ../admin/bulk.php');
    exit;
}

if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
    $_SESSION['error'] = 'Please upload a valid CSV file';
    header('Location: ../admin/bulk.php');
    exit;
}

$file = $_FILES['csv_file']['tmp_name'];
$role_id = (int)($_POST['role_id'] ?? 2);

try {
    $result = importUsersFromCSV($file, $pdo, $role_id);
    
    logActivity($pdo, $_SESSION['user_id'], 'bulk_import_users', "Imported {$result['success']} users, {$result['failed']} failed");
    
    if ($result['success'] > 0) {
        $_SESSION['success'] = "Successfully imported {$result['success']} users. Failed: {$result['failed']}";
    } else {
        $_SESSION['error'] = "Import failed. Errors: " . implode(', ', array_slice($result['errors'], 0, 5));
    }
    
} catch(Exception $e) {
    $_SESSION['error'] = 'Import failed: ' . $e->getMessage();
}

header('Location: ../admin/bulk.php');
exit;
?>