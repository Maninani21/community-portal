<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
requireAdmin();

$template_id = (int)($_GET['id'] ?? 0);

try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM certificates WHERE template_id = ?");
    $stmt->execute([$template_id]);
    $count = $stmt->fetch()['count'];
    
    if ($count > 0) {
        $_SESSION['error'] = "Cannot delete. Template used in $count certificates";
    } else {
        $stmt = $pdo->prepare("DELETE FROM certificate_templates WHERE id = ?");
        $stmt->execute([$template_id]);
        logActivity($pdo, $_SESSION['user_id'], 'delete_template', "Deleted template ID: $template_id");
        $_SESSION['success'] = 'Template deleted';
    }
} catch(PDOException $e) {
    $_SESSION['error'] = 'Failed to delete template';
}

header('Location: ../admin/templates.php');
exit;
?>

