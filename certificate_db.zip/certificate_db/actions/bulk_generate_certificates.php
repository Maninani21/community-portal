<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    $_SESSION['error'] = 'Invalid request';
    header('Location: ../admin/bulk.php');
    exit;
}

$template_id = (int)($_POST['template_id'] ?? 0);
$user_ids = $_POST['user_ids'] ?? [];
$course_name = trim($_POST['course_name'] ?? '');
$issue_date = $_POST['issue_date'] ?? date('Y-m-d');

if (empty($user_ids) || $template_id == 0 || empty($course_name)) {
    $_SESSION['error'] = 'Please fill all required fields and select users';
    header('Location: ../admin/bulk.php');
    exit;
}

try {
    $result = generateBulkCertificates($pdo, $template_id, $user_ids, $course_name, $issue_date, $_SESSION['user_id']);
    
    logActivity($pdo, $_SESSION['user_id'], 'bulk_generate_certificates', "Generated {$result['success']} certificates, {$result['failed']} failed");
    
    if ($result['success'] > 0) {
        $_SESSION['success'] = "Successfully generated {$result['success']} certificates! Failed: {$result['failed']}";
    } else {
        $_SESSION['error'] = "Generation failed. Errors: " . implode(', ', array_slice($result['errors'], 0, 5));
    }
    
} catch(Exception $e) {
    $_SESSION['error'] = 'Generation failed: ' . $e->getMessage();
}

header('Location: ../admin/bulk.php');
exit;
?>
