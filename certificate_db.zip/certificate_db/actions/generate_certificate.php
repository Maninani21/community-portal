<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    $_SESSION['error'] = 'Invalid request';
    header('Location: ../admin/certificates.php');
    exit;
}

$user_id = (int)($_POST['user_id'] ?? 0);
$template_id = (int)($_POST['template_id'] ?? 0);
$issue_date = $_POST['issue_date'] ?? date('Y-m-d');
$variables = $_POST['variables'] ?? [];

try {
    $stmt = $pdo->prepare("SELECT * FROM certificate_templates WHERE id = ? AND is_active = 1");
    $stmt->execute([$template_id]);
    $template = $stmt->fetch();
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND is_active = 1");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$template || !$user) {
        $_SESSION['error'] = 'Template or user not found';
        header('Location: ../admin/certificates.php');
        exit;
    }
    
    $cert_number = generateCertificateNumber($pdo);
    
    $cert_data = [];
    foreach ($variables as $key => $value) {
        $cert_data[$key] = sanitize($value);
    }
    $cert_data['certificate_id'] = $cert_number;
    $cert_data['issue_date'] = date('F d, Y', strtotime($issue_date));
    
    $cert_html = generateCertificateHTML($template['template_html'], $cert_data);
    $file_path = saveCertificateAsHTML($cert_html, $cert_number, $template['background_image']);
    
    $stmt = $pdo->prepare("INSERT INTO certificates (certificate_number, user_id, template_id, certificate_data, file_path, issued_date, issued_by, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'active')");
    $stmt->execute([$cert_number, $user_id, $template_id, json_encode($cert_data), $file_path, $issue_date, $_SESSION['user_id']]);
    
    logActivity($pdo, $_SESSION['user_id'], 'generate_certificate', "Generated certificate: $cert_number");
    $_SESSION['success'] = "Certificate generated: $cert_number";
    
} catch(Exception $e) {
    $_SESSION['error'] = 'Failed to generate certificate';
}

header('Location: ../admin/certificates.php');
exit;
?>