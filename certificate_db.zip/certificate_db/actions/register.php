<?php
session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../register.php');
    exit;
}

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$address = trim($_POST['address'] ?? '');
$password = $_POST['password'] ?? '';
$confirm = $_POST['confirm_password'] ?? '';

if (empty($name) || empty($email) || empty($password)) {
    $_SESSION['error'] = 'Please fill all required fields';
    header('Location: ../register.php');
    exit;
}

if ($password !== $confirm) {
    $_SESSION['error'] = 'Passwords do not match';
    header('Location: ../register.php');
    exit;
}

if (strlen($password) < 6) {
    $_SESSION['error'] = 'Password must be at least 6 characters';
    header('Location: ../register.php');
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->fetch()) {
        $_SESSION['error'] = 'Email already registered';
        header('Location: ../register.php');
        exit;
    }
    
    $hashed = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, address, password, role_id, is_active) VALUES (?, ?, ?, ?, ?, 2, 1)");
    $stmt->execute([$name, $email, $phone, $address, $hashed]);
    
    $_SESSION['success'] = 'Registration successful! Please login.';
    header('Location: ../index.php');
    exit;
    
} catch(PDOException $e) {
    error_log("Registration error: " . $e->getMessage());
    $_SESSION['error'] = 'Registration failed';
    header('Location: ../register.php');
    exit;
}
?>

