<?php
session_start();
require_once '../config/database.php';

$is_admin = isset($_SESSION['role_name']) && $_SESSION['role_name'] === 'admin';

if (isset($_SESSION['user_id'])) {
    try {
        $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)");
        $stmt->execute([$_SESSION['user_id'], 'logout', 'User logged out', $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0']);
    } catch(PDOException $e) {
        error_log("Logout log error: " . $e->getMessage());
    }
}

session_destroy();
session_start();
$_SESSION['success'] = 'Logged out successfully';

if ($is_admin) {
    header('Location: ../admin/login.php');
} else {
    header('Location: ../index.php');
}
exit;
?>