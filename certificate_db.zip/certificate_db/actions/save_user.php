<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    $_SESSION['error'] = 'Invalid request';
    header('Location: ../admin/users.php');
    exit;
}

$user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : null;
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$address = trim($_POST['address'] ?? '');
$password = $_POST['password'] ?? '';
$role_id = (int)($_POST['role_id'] ?? 2);
$is_active = isset($_POST['is_active']) ? 1 : 0;

if (empty($name) || empty($email)) {
    $_SESSION['error'] = 'Name and email required';
    header('Location: ../admin/users.php');
    exit;
}

try {
    if ($user_id) {
        if (!empty($password)) {
            $hashed = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE users SET name=?, email=?, phone=?, address=?, password=?, role_id=?, is_active=? WHERE id=?");
            $stmt->execute([$name, $email, $phone, $address, $hashed, $role_id, $is_active, $user_id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET name=?, email=?, phone=?, address=?, role_id=?, is_active=? WHERE id=?");
            $stmt->execute([$name, $email, $phone, $address, $role_id, $is_active, $user_id]);
        }
        logActivity($pdo, $_SESSION['user_id'], 'update_user', "Updated user: $name");
        $_SESSION['success'] = 'User updated successfully';
    } else {
        if (empty($password)) {
            $_SESSION['error'] = 'Password required for new user';
            header('Location: ../admin/users.php');
            exit;
        }
        $hashed = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, address, password, role_id, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $email, $phone, $address, $hashed, $role_id, $is_active]);
        logActivity($pdo, $_SESSION['user_id'], 'create_user', "Created user: $name");
        $_SESSION['success'] = 'User created successfully';
    }
    
} catch(PDOException $e) {
    $_SESSION['error'] = 'Failed to save user';
}

header('Location: ../admin/users.php');
exit;
?>
