<?php
session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../index.php');
    exit;
}

$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    $_SESSION['error'] = 'Please provide email and password';
    header('Location: ../index.php');
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT u.*, r.role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if (!$user || $user['role_name'] === 'admin') {
        $_SESSION['error'] = 'Invalid credentials';
        header('Location: ../index.php');
        exit;
    }
    
    if ($user['is_active'] != 1) {
        $_SESSION['error'] = 'Account is deactivated';
        header('Location: ../index.php');
        exit;
    }
    
    if (!password_verify($password, $user['password'])) {
        $_SESSION['error'] = 'Invalid credentials';
        header('Location: ../index.php');
        exit;
    }
    
    session_regenerate_id(true);
    
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['role_name'] = $user['role_name'];
    
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, description, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user['id'], 'user_login', 'User logged in', $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0']);
    
    header('Location: ../index.php');
    exit;
    
} catch(PDOException $e) {
    error_log("Login error: " . $e->getMessage());
    $_SESSION['error'] = 'Login failed';
    header('Location: ../index.php');
    exit;
}
?>
