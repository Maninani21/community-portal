<?php
session_start();
require_once '../config/database.php'; // make sure this defines $pdo

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../admin/login.php');
    exit;
}

$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    $_SESSION['error'] = 'Please provide email and password';
    header('Location: ../admin/login.php');
    exit;
}

try {
    // Fetch user + role
    $stmt = $pdo->prepare("
        SELECT u.id, u.name, u.email, u.password, u.is_active, r.role_name
        FROM users u
        JOIN roles r ON u.role_id = r.id
        WHERE u.email = ?
        LIMIT 1
    ");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $_SESSION['error'] = 'Email not found';
        header('Location: ../admin/login.php');
        exit;
    }

    // Check role
    if ($user['role_name'] !== 'admin') {
        $_SESSION['error'] = 'Invalid admin credentials';
        header('Location: ../admin/login.php');
        exit;
    }

    // Check active
    if ((int)$user['is_active'] !== 1) {
        $_SESSION['error'] = 'Account is deactivated';
        header('Location: ../admin/login.php');
        exit;
    }

    // Verify password (hashed)
    if (!password_verify($password, $user['password'])) {
        $_SESSION['error'] = 'Invalid password';
        header('Location: ../admin/login.php');
        exit;
    }

    // Login success
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['role_name'] = $user['role_name'];
    $_SESSION['is_admin'] = true;

    // Log activity
    $stmt = $pdo->prepare("
        INSERT INTO activity_logs (user_id, action, description, ip_address)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$user['id'], 'admin_login', 'Admin logged in', $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0']);

    // Redirect to admin dashboard
    header('Location: ../admin/index.php');
    exit;

} catch (PDOException $e) {
    error_log("Admin login error: " . $e->getMessage());
    $_SESSION['error'] = 'Login failed due to server error';
    header('Location: ../admin/login.php');
    exit;
}
