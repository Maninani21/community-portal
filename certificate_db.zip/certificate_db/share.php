<?php
session_start();
require_once 'config/database.php';

$cert_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$certificate = null;

if ($cert_id > 0) {
    try {
        $stmt = $pdo->prepare("
            SELECT c.*, u.name as user_name, t.template_name
            FROM certificates c
            JOIN users u ON c.user_id = u.id
            JOIN certificate_templates t ON c.template_id = t.id
            WHERE c.id = ? AND c.status = 'active'
        ");
        $stmt->execute([$cert_id]);
        $certificate = $stmt->fetch();
    } catch(PDOException $e) {
        // Handle error
    }
}

if (!$certificate) {
    header('Location: index.php');
    exit;
}

$cert_url = 'http://' . $_SERVER['HTTP_HOST'] . '/certificate_db/' . $certificate['file_path'];
$verify_url = 'http://' . $_SERVER['HTTP_HOST'] . '/certificate_db/verify.php?cert=' . urlencode($certificate['certificate_number']);
$share_url = 'http://' . $_SERVER['HTTP_HOST'] . '/certificate_db/share.php?id=' . $cert_id;

$share_text = "I'm proud to share that I've earned a certificate in " . $certificate['template_name'] . "! 🎓✨";
$share_title = "Certificate Achievement - " . $certificate['user_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Share Certificate - <?php echo htmlspecialchars($certificate['user_name']); ?></title>
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo htmlspecialchars($share_url); ?>">
    <meta property="og:title" content="<?php echo htmlspecialchars($share_title); ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($share_text); ?>">
    <meta property="og:image" content="<?php echo htmlspecialchars($cert_url); ?>">
    
    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="<?php echo htmlspecialchars($share_url); ?>">
    <meta property="twitter:title" content="<?php echo htmlspecialchars($share_title); ?>">
    <meta property="twitter:description" content="<?php echo htmlspecialchars($share_text); ?>">
    <meta property="twitter:image" content="<?php echo htmlspecialchars($cert_url); ?>">
    
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .share-container {
            min-height: 100vh;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 40px 20px;
        }
        .share-box {
            max-width: 700px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .cert-preview {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 20px;
            margin: 30px 0;
            text-align: center;
        }
        .cert-preview img {
            max-width: 100%;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .share-buttons {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 30px 0;
        }
        .share-btn {
            padding: 15px 20px;
            border-radius: 12px;
            text-decoration: none;
            color: white;
            font-weight: 600;
            text-align: center;
            transition: transform 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        .share-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.2);
        }
        .share-facebook { background: #1877f2; }
        .share-twitter { background: #1da1f2; }
        .share-linkedin { background: #0077b5; }
        .share-whatsapp { background: #25d366; }
        .share-telegram { background: #0088cc; }
        .share-email { background: #ea4335; }
        .copy-link-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 12px;
            margin: 20px 0;
        }
        .copy-input-group {
            display: flex;
            gap: 10px;
        }
        .copy-input {
            flex: 1;
            padding: 12px;
            border: 2px solid #dee2e6;
            border-radius: 8px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="share-container">
        <div class="share-box">
            <div style="text-align: center; margin-bottom: 30px;">
                <h1>📢 Share Your Achievement!</h1>
                <p style="color: #666;">Let the world know about your success</p>
            </div>
            
            <div class="cert-preview">
                <h3 style="margin-bottom: 15px;">Certificate Preview</h3>
                <p><strong><?php echo htmlspecialchars($certificate['certificate_number']); ?></strong></p>
                <p><?php echo htmlspecialchars($certificate['template_name']); ?></p>
                <p style="color: #666;">Issued: <?php echo date('F d, Y', strtotime($certificate['issued_date'])); ?></p>
            </div>
            
            <h3 style="margin: 30px 0 15px;">Share on Social Media</h3>
            <div class="share-buttons">
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode($verify_url); ?>&quote=<?php echo urlencode($share_text); ?>" 
                   target="_blank" class="share-btn share-facebook">
                    📘 Facebook
                </a>
                
                <a href="https://twitter.com/intent/tweet?text=<?php echo urlencode($share_text); ?>&url=<?php echo urlencode($verify_url); ?>&hashtags=certificate,achievement" 
                   target="_blank" class="share-btn share-twitter">
                    🐦 Twitter
                </a>
                
                <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo urlencode($verify_url); ?>" 
                   target="_blank" class="share-btn share-linkedin">
                    💼 LinkedIn
                </a>
                
                <a href="https://wa.me/?text=<?php echo urlencode($share_text . ' ' . $verify_url); ?>" 
                   target="_blank" class="share-btn share-whatsapp">
                    💬 WhatsApp
                </a>
                
                <a href="https://t.me/share/url?url=<?php echo urlencode($verify_url); ?>&text=<?php echo urlencode($share_text); ?>" 
                   target="_blank" class="share-btn share-telegram">
                    ✈️ Telegram
                </a>
                
                <a href="mailto:?subject=<?php echo urlencode($share_title); ?>&body=<?php echo urlencode($share_text . "\n\nVerify: " . $verify_url); ?>" 
                   class="share-btn share-email">
                    📧 Email
                </a>
            </div>
            
            <div class="copy-link-section">
                <h4 style="margin-bottom: 15px;">📋 Copy Verification Link</h4>
                <div class="copy-input-group">
                    <input type="text" id="verifyLink" class="copy-input" value="<?php echo htmlspecialchars($verify_url); ?>" readonly>
                    <button onclick="copyLink()" class="btn btn-primary">Copy</button>
                </div>
                <p style="font-size: 13px; color: #666; margin-top: 10px;">
                    Share this link to let others verify your certificate
                </p>
            </div>
            
            <div style="text-align: center; margin-top: 30px;">
                <a href="<?php echo htmlspecialchars($certificate['file_path']); ?>" target="_blank" 
                   class="btn btn-success">View Full Certificate</a>
                <a href="index.php" class="btn btn-secondary">Back to Dashboard</a>
            </div>
        </div>
    </div>
    
    <script>
        function copyLink() {
            const input = document.getElementById('verifyLink');
            input.select();
            document.execCommand('copy');
            alert('✅ Link copied to clipboard!');
        }
    </script>
</body>
</html>