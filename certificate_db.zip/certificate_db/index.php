<?php
session_start();

if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['role_name']) && $_SESSION['role_name'] === 'admin') {
        header('Location: admin/index.php');
        exit;
    }
    // User logged in, show their certificates
}

$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate System - User Portal</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php if (!isset($_SESSION['user_id'])): ?>
    <!-- LOGIN VIEW -->
    <div class="login-container">
        <div class="login-box advanced-login">
            <div class="login-header">
                <h1>🎓 Certificate Portal</h1>
                <p>Access Your Digital Certificates</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><strong>Error!</strong> <?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><strong>Success!</strong> <?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <form action="actions/user_login.php" method="POST" class="advanced-form">
                <div class="form-group">
                    <label for="email">📧 Email Address</label>
                    <input type="email" id="email" name="email" class="form-control" required autofocus>
                </div>
                
                <div class="form-group">
                    <label for="password">🔒 Password</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block btn-large">Login to View Certificates</button>
            </form>
            
            <div class="login-footer">
                <p>Don't have an account? <a href="register.php">Register Here</a></p>
                <p class="admin-link">Administrator? <a href="admin/login.php">Admin Login</a></p>
            </div>
        </div>
    </div>
    
    <?php else: ?>
    <!-- USER DASHBOARD VIEW -->
    <?php
    require_once 'config/database.php';
    
    $stmt = $pdo->prepare("
        SELECT c.*, t.template_name 
        FROM certificates c 
        JOIN certificate_templates t ON c.template_id = t.id 
        WHERE c.user_id = ? AND c.status = 'active'
        ORDER BY c.created_at DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $certificates = $stmt->fetchAll();
    ?>
    
    <nav class="navbar user-navbar">
        <div class="container">
            <div class="nav-brand">🎓 My Certificates</div>
            <ul class="nav-menu">
                <li><span>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></span></li>
                <li><a href="actions/logout.php" class="logout-btn">Logout</a></li>
            </ul>
        </div>
    </nav>
    
    <div class="main-content">
        <div class="container">
            <div class="user-dashboard">
                <div class="dashboard-header">
                    <h1>📜 Your Certificates</h1>
                    <p>Total: <strong><?php echo count($certificates); ?></strong> certificate(s)</p>
                </div>
                
                <?php if (empty($certificates)): ?>
                <div class="empty-state">
                    <div class="empty-icon">📭</div>
                    <h2>No Certificates Yet</h2>
                    <p>You don't have any certificates at the moment. They will appear here once issued.</p>
                </div>
                <?php else: ?>
                <div class="certificates-grid">
                    <?php foreach ($certificates as $cert): ?>
                    <div class="certificate-card">
                        <div class="cert-icon">🏆</div>
                        <h3><?php echo htmlspecialchars($cert['template_name']); ?></h3>
                        <p class="cert-number"><?php echo htmlspecialchars($cert['certificate_number']); ?></p>
                        <p class="cert-date">Issued: <?php echo date('d M Y', strtotime($cert['issued_date'])); ?></p>
                        <div class="cert-actions">
                            <a href="<?php echo htmlspecialchars($cert['file_path']); ?>" target="_blank" class="btn btn-sm btn-primary">View</a>
                            <a href="<?php echo htmlspecialchars($cert['file_path']); ?>" download class="btn btn-sm btn-success">Download</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php foreach ($certificates as $cert): ?>
<div class="certificate-card">
    <div class="cert-icon">🏆</div>
    <h3><?php echo htmlspecialchars($cert['template_name']); ?></h3>
    <p class="cert-number"><?php echo htmlspecialchars($cert['certificate_number']); ?></p>
    <p class="cert-date">Issued: <?php echo date('d M Y', strtotime($cert['issued_date'])); ?></p>
    
    <div class="cert-actions">
        <a href="<?php echo htmlspecialchars($cert['file_path']); ?>" target="_blank" 
           class="btn btn-sm btn-primary">👁️ View</a>
        <a href="<?php echo htmlspecialchars($cert['file_path']); ?>" download 
           class="btn btn-sm btn-success">⬇️ Download</a>
    </div>
    
    <div class="cert-actions" style="margin-top: 10px;">
        <a href="share.php?id=<?php echo $cert['id']; ?>" 
           class="btn btn-sm" style="background: #1877f2; color: white;">
           📢 Share
        </a>
        <a href="verify.php?cert=<?php echo urlencode($cert['certificate_number']); ?>" 
           target="_blank" class="btn btn-sm" style="background: #28a745; color: white;">
           ✅ Verify
        </a>
    </div>
</div>
<?php endforeach; ?>
    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Certificate System. All rights reserved.</p>
        </div>
    </footer>
    <?php endif; ?>
</body>
</html>