<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Certificate System</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-box advanced-login" style="max-width: 600px;">
            <div class="login-header">
                <h1>📝 Create Account</h1>
                <p>Register to access your certificates</p>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <form action="actions/register.php" method="POST" class="advanced-form" id="regForm">
                <div class="form-row">
                    <div class="form-group">
                        <label for="name">👤 Full Name</label>
                        <input type="text" id="name" name="name" class="form-control" required minlength="3">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">📧 Email Address</label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="phone">📱 Phone Number</label>
                        <input type="tel" id="phone" name="phone" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label for="address">🏠 Address</label>
                        <input type="text" id="address" name="address" class="form-control">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="password">🔒 Password</label>
                        <input type="password" id="password" name="password" class="form-control" required minlength="6">
                        <div id="strength" class="password-strength"></div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">🔒 Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="terms" required>
                        I agree to the Terms and Conditions
                    </label>
                </div>
                
                <button type="submit" class="btn btn-success btn-block btn-large">Create Account</button>
            </form>
            
            <div class="login-footer">
                <p>Already have an account? <a href="index.php">Login Here</a></p>
            </div>
        </div>
    </div>
    
    <script>
        document.getElementById('password').addEventListener('input', function() {
            const pwd = this.value;
            const strength = document.getElementById('strength');
            let score = 0;
            
            if (pwd.length >= 6) score++;
            if (pwd.length >= 10) score++;
            if (/[a-z]/.test(pwd) && /[A-Z]/.test(pwd)) score++;
            if (/\d/.test(pwd)) score++;
            if (/[^a-zA-Z\d]/.test(pwd)) score++;
            
            strength.className = 'password-strength';
            if (score <= 2) {
                strength.classList.add('weak');
                strength.textContent = 'Weak';
            } else if (score <= 3) {
                strength.classList.add('medium');
                strength.textContent = 'Medium';
            } else {
                strength.classList.add('strong');
                strength.textContent = 'Strong';
            }
        });
        
        document.getElementById('regForm').addEventListener('submit', function(e) {
            const pwd = document.getElementById('password').value;
            const cpwd = document.getElementById('confirm_password').value;
            
            if (pwd !== cpwd) {
                e.preventDefault();
                alert('Passwords do not match!');
                return false;
            }
        });
    </script>
</body>
</html>
